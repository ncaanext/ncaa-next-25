
TEXTURES DISABLER SCRIPT

ABOUT:

This script will "disable" all textures that are alongside it in the same folder (including all 
subfolders) by prepending the names with a dash ("-"). This disables the textures so you can 
use custom/alternate/DLC textures in your user-customs folder. 

INSTRUCTIONS: 

1. Copy the "_TEXTURES-DISABLE" bat file into any uniform or other folder (Eg. home, away, alt01).

2. Double-click the bat file to run the script. 

That's it! It will rename all of the textures by prepending the name with a dash, allowing you 
to use your custom uniform (or other textures) in the user-customs folder. 

- Always put your custom uniform/textures in the user-customs folder in replacements.

- Want to re-enable the default uniform/textures? Just repeat the process using 
  the "_TEXTURES-ENABLE" bat file.

- NOTE: To avoid catastrophic misuse, the script is limited to renaming 80 files at a time. 

For discussion and support, visit the NCAA NEXT Discord server and search for the 
"Uniform Disabler/Enabler Script" thread in #community-mod-releases. 
Direct link: https://discord.com/channels/938236373113122826/1283426413608833117