#!/bin/bash

# Initialize counter variables
countFound=0
countRenamed=0
maxRenames=80

# Store current directory
currentDir="$(pwd)"

# Start logging
echo "Script started..."
echo "Current directory: $currentDir"
echo "Looking for PNG files..."
echo

# Cleanup old temporary scripts if they exist
find /tmp -name 'ncaanext_textures_del_script_*.sh' -type f -delete
find /private/tmp -name 'ncaanext_textures_del_script_*.sh' -type f -delete

# Function to process PNG files only
process_folder() {
    echo "Processing files in $currentDir..."
    find "$currentDir" -type f -name "*.png" | while read -r file; do
        fileName=$(basename "$file")
        filePath=$(dirname "$file")

        # Debug output
        # echo "Processing file: $file"

        # Get the relative path (strip current directory from the file path)
        relativePath="${file#$currentDir/}"

        # Check if the file does not start with a dash
        if [[ "${fileName:0:1}" != "-" ]]; then
            ((countFound++))  # Increment count of files found

            # If renamed files reach 40, display warning and stop script
            if ((countRenamed >= maxRenames)); then
                echo
                echo "#####################################################"
                echo "#### ----------------- ERROR ------------------- ####"
                echo
                echo "Uh oh, we've disabled 80 textures, which is more than a single uniform contains."
                echo "You may have run this script from the wrong folder."
                echo "Stopping the script to prevent a catastrophic number of files from being renamed."
                echo
                echo "#####################################################"
                exit 1
            fi

            # Rename the file
            newFileName="-${fileName}"
            echo " "
            echo "Renaming file: $relativePath to $newFileName"
            mv "$file" "$filePath/$newFileName"
            if [[ $? -eq 0 ]]; then
                ((countRenamed++))  # Increment count of files renamed
                echo "Total textures disabled: $countRenamed"  # Debug output
                # echo "Successfully renamed: $file"  # Debug output
            else
                echo " "
                echo "Error renaming: $relativePath"
            fi
        else
            echo " "  # Debug output
            echo "File already starts with a dash: $relativePath"  # Debug output
        fi
    done
}

# Call the function to process files
process_folder

# Output the summary
echo
echo "============================"
# echo "Total # of PNG files found: $countFound"
# echo "Total # of textures disabled: $countRenamed"
echo "Done. Textures disabled."
echo "============================"
echo
echo "Heads up: This script will delete itself when you press a key to continue."
echo

# Wait for user input
read -p "Press [Enter] to continue..."

# Instead of creating a self-deleting script, simply delete the script itself
rm -- "$0"